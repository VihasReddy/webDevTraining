function onClick(){
    var list = document.getElementById("list");
    var text = document.getElementById("text");
    list.insertAdjacentHTML('beforeend', '<div id="'+text.value+'Created" style="text-align: center; background-color:blue;"><ul><li><button id="'+text.value+'" type="button" onclick="toggleText(this.id)" style="margin-right: 5cm;">Toggle</button>'+text.value+'<button id="'+text.value+'" type="button" onclick="deleteText(this.id)" style="margin-left: 5cm;">Delete</button></li></ul></div>');
}

function deleteText(id){
    var div = document.getElementById(id+"Created");
    div.innerHTML="";
}

function toggleText(id){
    var div = document.getElementById(id+"Created");
    if(div.style.background = "blue"){
        div.style.background = "red";
    }
    else{    
        div.style.background = "blue";
    }
}